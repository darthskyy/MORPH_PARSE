Please contact me (cael.marquard@gmail.com or MRQCAE001@myuct.ac.za) for all the models. They could not be uploaded due
to size constraints. Alternatively, visit the repository at https://github.com/darthskyy/MORPH_PARSE/ and get them from
there.
