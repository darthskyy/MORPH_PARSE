# Note to markers

For this submission, I've excluded the .git/ and (most of the) out_models/ directory. This is because they are large
(1GiB together, in total). They can be obtained from the GitHub repo https://github.com/DarthSkyy/MORPH_PARSE if desired
(email me or Francois for access). However, they are just artefacts and not the code itself.
