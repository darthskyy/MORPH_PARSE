# MORPH_PARSE

Morphological parsing NLP project by Cael Marquad and Simbarashe Mawere.

README for the PLM part is located in the ```plm``` subdirectory [PLM README.md](./plm/README.md)

<!-- insert copyright -->
Copyright © [2024] [Cael Marquard & Simbarashe Mawere]
